const { default: axios } = require("axios");
const { oauth2Client } = require("../util/googleConfig");
const { v4: uuidv4 } = require("uuid");
const { Users } = require("../model/arrayUser");
const jwt = require("jsonwebtoken");

const googleLogin = async (req, res) => {
  try {
    const { code } = req.query;

    // Get tokens from Google OAuth2
    const googleRes = await oauth2Client.getToken(code);
    oauth2Client.setCredentials(googleRes.tokens);

    // Fetch user info
    const userRes = await axios.get(
      `https://www.googleapis.com/oauth2/v1/userinfo?alt=json&access_token=${googleRes.tokens.access_token}`
    );

    const { email, name, picture } = userRes.data;

    // Check if user already exists
    let user = Users.find((usr) => usr.email === email);

    if (!user) {
      user = { id: uuidv4(), name, email, image: picture };
      Users.push(user);
    }
    const { id } = user;

    const token = jwt.sign({ id, email }, "tus", { expiresIn: "12h" });

    return res.status(200).json({
      message: "success",
      token,
      user,
    });
  } catch (error) {
    console.error("Google Login Error:", error.message);
    res.status(500).json({ error: "Authentication failed" });
  }
};

module.exports = googleLogin;
