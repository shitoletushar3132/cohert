const Users = [{}];

module.exports = { Users };
