const express = require("express");
const router = require("./routes/authRouter");
const cors = require("cors");

const app = express();

const PORT = 3000;

app.use(cors());

app.use("/auth", router);

app.get("/", (req, res) => {
  res.send("hello");
});

app.listen(PORT, () => console.log("start"));
