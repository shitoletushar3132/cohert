const { google } = require("googleapis");

const GOOGLE_CLIENT_ID =
  "587438245291-1uthlbgu0rnl86c4kfg37vdg80qchr74.apps.googleusercontent.com";

const GOOGLE_CLIENT_SECRET = "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";

exports.oauth2Client = new google.auth.OAuth2(
  GOOGLE_CLIENT_ID,
  GOOGLE_CLIENT_SECRET,
  "post"
);
