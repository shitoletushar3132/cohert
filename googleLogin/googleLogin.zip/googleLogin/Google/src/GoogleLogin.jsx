import React from "react";
import { useGoogleLogin } from "@react-oauth/google";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const GoogleLogin = ({ setUserData }) => {
  const Navigate = useNavigate();
  const responseGoogle = async (authResult) => {
    try {
      if (authResult["code"]) {
        const result = await axios.get(
          `http://localhost:3000/auth/google?code=${authResult["code"]}`
        );
        const { email, name, image } = result.data.user;
        setUserData({ email, name, image });
        Navigate("/dash");
      }
    } catch (error) {
      console.log(error);
    }
  };

  const googleLogin = useGoogleLogin({
    onSuccess: responseGoogle,
    onError: responseGoogle,
    flow: "auth-code",
  });
  return (
    <div>
      <button onClick={googleLogin}>Login With Google</button>
    </div>
  );
};

export default GoogleLogin;
