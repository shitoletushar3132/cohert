import React, { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Dash = ({ userData }) => {
  const Navigate = useNavigate();
  useEffect(() => {
    if (userData.email === "") {
      Navigate("/");
    }
  }, []);

  return (
    <div>
      <img src={`${userData.image}`} />
      <h1>{userData.name}</h1>
      <h1>{userData.email}</h1>
    </div>
  );
};

export default Dash;
