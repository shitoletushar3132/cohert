import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { GoogleOAuthProvider } from "@react-oauth/google";
import GoogleLogin from "./GoogleLogin";
import { useState } from "react";
import Dash from "./Dash";

function App() {
  const [userData, setUserData] = useState({ email: "", name: "", image: "" });
  return (
    <GoogleOAuthProvider clientId="587438245291-1uthlbgu0rnl86c4kfg37vdg80qchr74.apps.googleusercontent.com">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<GoogleLogin setUserData={setUserData} />} />
          <Route path="/dash" element={<Dash userData={userData} />} />
        </Routes>
      </BrowserRouter>
    </GoogleOAuthProvider>
  );
}

export default App;
